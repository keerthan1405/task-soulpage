import React from 'react';
import MasterView from './components/MasterView';
import './App.css';

function App() {
  return (
    <div className="container-fluid mt-3">
      <MasterView />
    </div>
  );
}

export default App;
