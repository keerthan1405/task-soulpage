import React, { useState, useEffect, useCallback } from 'react'

const MasterViewTable =(props:any)=>{

  const [repositories, setRepositories] = useState([]);

  // const forceUpdate = useforceUpdate;

  useEffect(()=>{
    fetch("https://api.github.com/repositories")
    .then(res => res.json())
    .then((data)=>{
      data.map((x:any)=>x.isFavorite="false")
      setRepositories(data)
    })
    .catch((err)=>{
      console.log(err);
    });
  },[])


const favoriteHandler = (id:number) =>{
  console.log(id);
  // var findIndex = repositories.findIndex((x:any) => x.id === id);
  //   console.log(findIndex, repositories[findIndex], repositories[findIndex].isFavorite);
    
    // if(repositories[findIndex].isFavorite){
    //   repositories[findIndex].isFavorite = "false";
    //   console.log("if");
    // }else{
    //   repositories[findIndex].isFavorite = "true";
    //   console.log("else");
    // }
    setRepositories(repositories)
}

  

  const boxLayout = repositories.map((item:any, index:number)=>{
    console.log("123456");
    return(
      <tr key={item.id}>
        <td>{index +1}</td>
    <td>{item.isFavorite}</td>
        <td><span onClick={()=>{favoriteHandler(item.id)}}><i className={item.isFavorite?"far fa-heart color-red":"far fa-heart"}></i></span></td>
        <td>{item.name}</td>
        <td>{item.full_name}</td>
        <td><a href={item.html_url} target="_blank">Click here to view Repository</a></td>
        <td><button className="btn btn-sm btn-outline-info">Click here to view Contributors</button></td>
      </tr>
    )
  })

  return (
    <div className="table-view">

      {
        repositories ? (
          <div className="table-data">
            <table className="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>S.No </th>
                  <th></th>
                  <th></th>
                  <th>Name </th>
                  <th>Full Name </th>
                  <th>Link </th>
                  <th>Contributors URL </th>
                </tr>
              </thead>
              <tbody>
                {boxLayout}
              </tbody>
            </table>
              
          </div>
        ):(
          <div>
            <h2>Loading...</h2>
          </div>
        )
      }
      </div>

  )
}


export default MasterViewTable

